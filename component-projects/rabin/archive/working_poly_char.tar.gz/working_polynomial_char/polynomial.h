#ifndef POLYNOMIAL_REDUCTION
#define POLYNOMIAL_REDUCTION

#include <stdbool.h>
#include <stdint.h>

unsigned char poly_mod(unsigned char* f, unsigned char p, int len);
bool keep_going(unsigned char* f, int len);
unsigned char* shift_array(unsigned char* f, int len);

#endif
