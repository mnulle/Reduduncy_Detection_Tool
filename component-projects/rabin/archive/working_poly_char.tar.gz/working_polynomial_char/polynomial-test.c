#include "polynomial.h"
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]) {
    //0100111000000000000000000000000000000000000000000000000000000000

    unsigned char *my_ints;
    unsigned char p = 145;
    my_ints = malloc(sizeof(uint64_t)*2);
    my_ints[0] = 154;
    my_ints[1] = 78;


    printf("%X\n", my_ints[0]);
    printf("%X\n", my_ints[1]);
    printf("%X\n", poly_mod(my_ints, p, 2));
/*    printf("%" PRIu64 "\n", my_ints[0]);
    printf("%" PRIu64 "\n", my_ints[1]);
    printf("%" PRIu64 "\n", poly_mod(my_ints, p, 2));
*/
    return 0;
}

//polynomialMod(x^15 + x^12 + x^11 + x^9 + x^6 + x^3 + x^2 + x, x^7 + x^4 + 1)
