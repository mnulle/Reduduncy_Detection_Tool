#include "rabin.h"
#include "polynomial.h"

uint32_t* buildA(uint32_t* p) {

	return p;
}
