#ifndef RABIN
#define RABIN

#include <stdint.h>

uint32_t* buildA(uint32_t* p);

#endif
