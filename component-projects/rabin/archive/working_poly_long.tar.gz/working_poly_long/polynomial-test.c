#include "polynomial.h"
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]) {
    //0100111000000000000000000000000000000000000000000000000000000000

    unsigned long *my_ints;
    unsigned long p = (4611686018427387905 / 16) + 1;
    my_ints = malloc(sizeof(unsigned long)*2);
    my_ints[0] = (4611686018427388033 / 16) + 1;
    my_ints[1] = 0;

    printf("Size of long is %d\n", sizeof(unsigned long));
    printf("%lX\n", my_ints[0]);
    printf("%lX\n", my_ints[1]);
    printf("%lX\n", poly_mod(my_ints, p, 2));
/*    printf("%" PRIu64 "\n", my_ints[0]);
    printf("%" PRIu64 "\n", my_ints[1]);
    printf("%" PRIu64 "\n", poly_mod(my_ints, p, 2));
*/
    return 0;
}

//polynomialMod(x^15 + x^12 + x^11 + x^9 + x^6 + x^3 + x^2 + x, x^7 + x^4 + 1)
