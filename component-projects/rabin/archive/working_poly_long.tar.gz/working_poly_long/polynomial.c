#include "polynomial.h"
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

#define ONE_BIT 127

unsigned long poly_mod(unsigned long* f, unsigned long p, int len) {
    int i;
    while(keep_going(f, len)) {
	for(i = 0; i < sizeof(p) * 8; i++) {
	    if(f[0] > ONE_BIT) {
		f[0] = f[0] ^ p;
	    }
	    shift_array(f, len);
	}
    }
    if(f[0] > ONE_BIT) 
	f[0] = f[0] ^ p;
    return f[0];
}

bool keep_going(unsigned long* f, int len) {
    int i;	
    for(i = 1; i < len; i++) {
	if(f[i] != 0) return true;
    }
    return false;
}

unsigned long* shift_array(unsigned long* f, int len) {
    int i;
    for(i = 0; i < len - 1; i++) {
        f[i] = f[i] << 1;
	if(f[i+1] > ONE_BIT) f[i]++;
    }
    f[len - 1] = f[len - 1] << 1;
    return f;
}
