#ifndef POLYNOMIAL_REDUCTION
#define POLYNOMIAL_REDUCTION

#include <stdbool.h>
#include <stdint.h>

unsigned long poly_mod(unsigned long* f, unsigned long p, int len);
bool keep_going(unsigned long* f, int len);
unsigned long* shift_array(unsigned long* f, int len);

#endif
