#include "polynomial.h"
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]) {

    unsigned long *my_ints;
    unsigned long *p;
    p = malloc(sizeof(unsigned long) * 2);
    p[1] = (4611686018427387905 / 16) + 1;
    p[0] = 0;

    my_ints = malloc(sizeof(unsigned long)*2);
    my_ints[0] = (4611686018427388033 / 16) + 1;
    my_ints[1] = 0;

    printf("Size of long is %d\n", sizeof(unsigned long));
    printf("%lX\n", my_ints[0]);
    printf("%lX\n", my_ints[1]);
    printf("%lX\n", poly_mod(my_ints, p, 2, 2));
    return 0;
}
