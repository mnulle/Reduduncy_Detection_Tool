#ifndef POLYNOMIAL_REDUCTION
#define POLYNOMIAL_REDUCTION

#include <stdbool.h>
#include <stdint.h>

unsigned long poly_mod(unsigned long* f, unsigned long* p, int len, int plen);
bool keep_going(unsigned long* f, int len, int plen);
unsigned long* shift_array(unsigned long* f, int len);

#endif
